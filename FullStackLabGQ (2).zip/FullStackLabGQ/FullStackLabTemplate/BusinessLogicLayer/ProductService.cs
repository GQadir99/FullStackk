﻿using System;
using System.Collections.Generic;
using System.Text;
using DataAccessLayer;
using Models;

namespace BusinessLogicLayer
{
    public class ProductService : IProductService
    {
        public List<ProductModel> GetAllData() => CRUD.GetAllData();

        public bool AddProduct(string name, int price) => CRUD.InsertProduct(name, price);

        public bool EditProduct(int id, string name, int price) => CRUD.UpdateProduct(id, name, price);

        public bool RemoveProduct(int id) => CRUD.DeleteProduct(id);
    }
}