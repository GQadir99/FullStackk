﻿using Models;
using System;
using System.Collections.Generic;
using System.Text;



namespace BusinessLogicLayer
{
    public interface IProductService
    {
        List<ProductModel> GetAllData();
        bool AddProduct(string name, int price);
        bool EditProduct(int id, string name, int price);
        bool RemoveProduct(int id);
    }
}