﻿using System;
using System.Collections.Generic;
using Npgsql;
using Models;

namespace DataAccessLayer
{
    public class CRUD
    {
        // 1. READ
        public static List<ProductModel> GetAllData()
        {
            List<ProductModel> products = new List<ProductModel>();
            string query = "SELECT \"PId\", \"PName\", \"Price\" FROM public.\"Products\";";

            using (NpgsqlConnection connection = DBHelper.GetConnection())
            {
                connection.Open();
                using (NpgsqlCommand command = new NpgsqlCommand(query, connection))
                using (NpgsqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        ProductModel model = new ProductModel
                        {
                            PId = Convert.ToInt32(reader["PId"]),
                            PName = reader["PName"].ToString(),
                            Price = Convert.ToInt32(reader["Price"])
                        };
                        products.Add(model);
                    }
                }
            }
            return products;
        }

        // 2. CREATE
        public static bool InsertProduct(string pName, int price)
        {
            string query = "INSERT INTO public.\"Products\" (\"PName\", \"Price\") VALUES (@PName, @Price);";

            using (NpgsqlConnection connection = DBHelper.GetConnection())
            {
                connection.Open();
                using (NpgsqlCommand command = new NpgsqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@PName", pName);
                    command.Parameters.AddWithValue("@Price", price);

                    int rowsAffected = command.ExecuteNonQuery();
                    return rowsAffected > 0;
                }
            }
        }

        // 3. UPDATE
        public static bool UpdateProduct(int pId, string pName, int price)
        {
            string query = "UPDATE public.\"Products\" SET \"PName\" = @PName, \"Price\" = @Price WHERE \"PId\" = @PId;";

            using (NpgsqlConnection connection = DBHelper.GetConnection())
            {
                connection.Open();
                using (NpgsqlCommand command = new NpgsqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@PId", pId);
                    command.Parameters.AddWithValue("@PName", pName);
                    command.Parameters.AddWithValue("@Price", price);

                    int rowsAffected = command.ExecuteNonQuery();
                    return rowsAffected > 0;
                }
            }
        }

        // 4. DELETE
        public static bool DeleteProduct(int pId)
        {
            string query = "DELETE FROM public.\"Products\" WHERE \"PId\" = @PId;";

            using (NpgsqlConnection connection = DBHelper.GetConnection())
            {
                connection.Open();
                using (NpgsqlCommand command = new NpgsqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@PId", pId);

                    int rowsAffected = command.ExecuteNonQuery();
                    return rowsAffected > 0;
                }
            }
        }
    }
}